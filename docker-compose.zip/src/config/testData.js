export const TestData = Object.freeze({
    users: {
      valid: { "email": "eve.holt@reqres.in", "password": "cityslicka" },
      invalid: { "email": "foo@bar.com", "password": "wrong" }
    }
  });
  